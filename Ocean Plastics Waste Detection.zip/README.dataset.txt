# Ocean Plastics Waste Detection - Float Plastics > 2023-08-13 7:30pm
https://universe.roboflow.com/abdelaadimkhriss/ocean-plastics-waste-detection-float-plastics

Provided by a Roboflow user
License: CC BY 4.0

